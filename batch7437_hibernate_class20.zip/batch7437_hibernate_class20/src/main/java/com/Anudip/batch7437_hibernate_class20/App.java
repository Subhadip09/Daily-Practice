package com.Anudip.batch7437_hibernate_class20;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        Student s = new Student(12, "Ayush", "Kolkata");
        
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("Student");
        
        EntityManager em = emf.createEntityManager();
        
        em.getTransaction().begin();
        
        em.persist(em);
        
        em.getTransaction().commit();
        
        em.close();
    }
}
